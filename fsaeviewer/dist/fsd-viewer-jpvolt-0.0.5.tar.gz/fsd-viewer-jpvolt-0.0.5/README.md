# fsdviewer
simple 2d viewer for formula student driverless software
